from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# ``app`` is importable because alembic.ini sets
# ``prepend_sys_path = %(here)s/backend`` — no manual sys.path edits here.
from app.core.config import settings
from app.db.database import Base

# app.models.__init__ imports every model module, so autogenerate sees the
# complete metadata (a partial list here would diff missing tables as drops).
import app.models  # noqa: F401

config = context.config

# Single source of truth for the DB URL: app.core.config.settings reads
# DATABASE_URL from the environment (.env in dev, real env vars in prod).
# alembic.ini intentionally has an empty sqlalchemy.url so nothing leaks
# into git. The CLI override `alembic -x url=...` still wins because we
# only fall back to settings when -x wasn't passed.
override = context.get_x_argument(as_dictionary=True).get("url")
database_url = override or settings.DATABASE_URL
if not database_url:
    raise RuntimeError(
        "DATABASE_URL is not configured. Set it in .env (or pass "
        "`alembic -x url=...` for one-off overrides)."
    )
# Escape % so ConfigParser doesn't interpret it as interpolation syntax —
# DATABASE_URLs commonly contain URL-encoded passwords with %xx escapes.
config.set_main_option("sqlalchemy.url", database_url.replace("%", "%%"))

if config.config_file_name is not None:
    # disable_existing_loggers=False: alembic.ini only names root/sqlalchemy/
    # alembic loggers, and fileConfig's DEFAULT (True) would disable every other
    # already-created logger — i.e. all of the app's `app.*` loggers — for the
    # rest of the process. That silently breaks in-process migration callers
    # (the test suite, or an app that runs `upgrade` at startup): app warnings
    # stop emitting until the process restarts. Keep existing loggers alive.
    fileConfig(config.config_file_name, disable_existing_loggers=False)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
